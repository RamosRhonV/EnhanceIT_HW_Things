//
//  MainScreenTableViewCell.swift
//  Apr4_NexGame_Iter2
//
//  Created by Consultant on 4/4/22.
//

import Foundation
import UIKit

class MainScreenTableViewCell: UITableViewCell {
    
    @IBOutlet weak var GameCover: UIImageView!
    @IBOutlet weak var GameTitleLabel: UILabel!
    @IBOutlet weak var GameGenreLabel: UILabel!
}
