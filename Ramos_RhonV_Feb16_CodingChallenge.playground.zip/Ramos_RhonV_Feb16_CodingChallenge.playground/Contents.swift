import UIKit

/*
 * Given an array of integers, nums, and an integer, target,
 * return the indices of the two numbers in nums that add
 * up to target
 */

// example array
var nums:[Int] = [2, 7, 8, 3, 7, 8]

// example Int
var target:Int = 14

// function findTargetIndices takes array and Int parameters
// returns two Int values
func findTargetIndices(numA:[Int], targetA:Int) -> (Int, Int)
{
    // xCount represents first index of array
    var xCount = 0
    
    // yCount represents second index of array
    var yCount = 0
    
    // nested for-loop iterates through array
    outerLoop:for x in 0..<numA.count
    {
        yCount = 1 // initialized to 1 to ensure yCount and xCount is not identical through first iteration
        for y in 1..<numA.count
        {
            // checks if sum of values at indices equal the target Int and
            // also if the x and y values do not point to the same indexed value
            if( (numA[x] + numA[y]) == target && (x != y))
            {
                // break entire for-loop block if statement is true
                break outerLoop
            }
            yCount += 1
        }
        xCount += 1
    }
    
    return (xCount, yCount)
}

// assigns returned tuple
var targetIndices = findTargetIndices(numA: nums, targetA: target)

// assigns tuple values to two distinct variables
var index1 = targetIndices.0
var index2 = targetIndices.1

// prints indices with values that sum to target in the format
// [<first index>, <second index>]
print("[\(index1),\(index2)]")



